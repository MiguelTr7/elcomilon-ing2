package cl.elcomilon.service;

import cl.elcomilon.dto.PlatoDTO;
import cl.elcomilon.model.Plato;
import cl.elcomilon.model.Proveedor;
import cl.elcomilon.repository.PlatoRepository;
import cl.elcomilon.repository.ProveedorRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PlatoService {
    @Autowired
    private PlatoRepository platoRepository;
    @Autowired
    private ProveedorRepository proveedorRepository; // si quieres validar el proveedor

    public List<Plato> getAll() {
        return platoRepository.findAll();
    }

    // Método para guardar Plato como entidad
    public Plato save(Plato plato) {
        return platoRepository.save(plato);
    }

    public void delete(Long id) {
        platoRepository.deleteById(id);
    }

    // Método recomendado para guardar desde un DTO
    public Plato save(@Valid PlatoDTO dto) {
        Plato plato = new Plato();
        plato.setNombre(dto.getNombre());
        plato.setDescripcion(dto.getDescripcion());
        plato.setPrecio(dto.getPrecio());
        plato.setDisponible(dto.isDisponible());
        if (dto.getProveedorId() != null) {
            // Opción rápida (setea solo el ID, no valida existencia)
            Proveedor proveedor = new Proveedor();
            proveedor.setId(dto.getProveedorId());
            plato.setProveedor(proveedor);
            // Opción robusta (descomenta si tienes ProveedorRepository y quieres validar):
            // Proveedor proveedor = proveedorRepository.findById(dto.getProveedorId()).orElse(null);
            // plato.setProveedor(proveedor);
        } else {
            plato.setProveedor(null);
        }
        return platoRepository.save(plato);
    }
    public boolean deleteByIdChecked(Long id) {
        if (!platoRepository.existsById(id)) {
            return false;
        }
        platoRepository.deleteById(id);
        return true;
    }

}
