package cl.elcomilon.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class PlatoDTO {
    private Long id;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @NotBlank(message = "La descripción es obligatoria")
    private String descripcion;

    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser positivo")
    private Integer precio;

    private boolean disponible;
    private Long proveedorId; // puede ser null si el plato es propio del restaurante
}
